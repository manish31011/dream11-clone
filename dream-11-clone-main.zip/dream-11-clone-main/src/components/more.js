import React from 'react';

function More() {
  return <div>more</div>;
}

export default More;
