export function leaderboardChanges(leaderboard) {
  console.log(leaderboard, 'leaderboard');
  return 'leader';
}
