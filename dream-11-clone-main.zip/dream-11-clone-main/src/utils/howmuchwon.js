const days = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];

const value = '';
export async function howmuchwon(contests, teams) {}
